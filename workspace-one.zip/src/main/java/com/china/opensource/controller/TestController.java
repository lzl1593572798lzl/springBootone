package com.china.opensource.controller;

import com.china.opensource.domain.TestUser;
import com.china.opensource.utils.AbstractController;
import com.china.opensource.utils.ResultData;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * create by lzl ON 2017/12/02
 */
@Controller
@RequestMapping("/user")
public class TestController extends AbstractController {

    @GetMapping("/get")
    public ResponseEntity<ResultData> test(){
        TestUser user = new TestUser(1L,"hello world","139651467087");
        return renderOk(mapOf("user",user));
    }
}
