package com.china.opensource.utils;

import java.util.Map;

/**
 * create by lzl ON 2017/12/02
 */
public class ResultData {

    /**
     *  状态码
     */
    private Integer code;
    /**
     * 返回结果状态描述
     */
    private String messgae;
    /**
     * 返回数据
     */
    private Map<String,Object> data;

    public ResultData(ResultCode resultCode) {
        this.code = resultCode.getCode();
        this.messgae = resultCode.getMessage();
    }

    public ResultData(ResultCode resultCode,String message){
        this.code = resultCode.getCode();
        this.messgae = message;
    }

    public ResultData(ResultCode resultCode, Map<String, Object> data) {
        this.code = resultCode.getCode();
        this.messgae = resultCode.getMessage();
        this.data = data;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessgae() {
        return messgae;
    }

    public void setMessgae(String messgae) {
        this.messgae = messgae;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }
}
