package com.china.opensource.utils;

import com.google.common.collect.ImmutableMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * create by lzl ON 2017/12/02
 */
public abstract class AbstractController {

    @Autowired
    private HttpServletResponse httpServletResponse;

    protected ResponseEntity<ResultData> renderOK(){
        return new ResponseEntity<ResultData>(HttpStatus.OK);
    }

    protected ResponseEntity<ResultData> renderOk(Map<String,Object> objectMap){
        ResultData data = new ResultData(ResultCode.OK,objectMap);
        return new ResponseEntity<ResultData>(data,HttpStatus.OK);
    }

    protected ResponseEntity<ResultData> renderError(ResultCode resultCode){
        ResultData resultData = new ResultData(resultCode);
        return new ResponseEntity<ResultData>(resultData,HttpStatus.OK);
    }

    protected ResponseEntity<ResultData> renderError(ResultCode resultCode,String messgae){
        ResultData resultData = new ResultData(resultCode,messgae);
        return new ResponseEntity<ResultData>(resultData,HttpStatus.OK);
    }

    protected Map<String,Object> mapOf(String key,Object value){
        return ImmutableMap.of(key,value);
    }

    protected Map<String,Object> mapOf(String keyOne,Object valueOne,String keyTwo,Object valueTwo){
        return ImmutableMap.of(keyOne,valueOne,keyTwo,valueTwo);
    }




}
