package com.china.opensource.utils;

/**
 * 请求结果的返回状态码
 * create by lzl ON 2017/12/02
 */
public enum  ResultCode {
    OK(0,"请求成功"),ERROR(500001,"服务器处理失败");
    ResultCode(Integer code,String message){
        this.code = code;
        this.message = message;
    }

    private Integer code;
    private String message;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
