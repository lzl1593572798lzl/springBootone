package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * create by lzl ON 2017/11/30
 */
@SpringBootApplication
public class SpringBootOne {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootOne.class,args);
    }

}
